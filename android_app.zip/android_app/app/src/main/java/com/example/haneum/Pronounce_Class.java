package com.example.haneum;

import com.google.gson.annotations.SerializedName;

/* Pronounce Assessement Class*/
public class Pronounce_Class {
    /* Test code */

    /*
    @SerializedName("text")
    private String text;

    public String getText(){
        return text;
    }
    */


    /*
    @SerializedName("userId")
    private  int userId;

    @SerializedName("id")
    private int id;

    @SerializedName("title")
    private String title;

    @SerializedName("body")
    private String body;

    public int getUserId(){
        return userId;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public String getBody(){
        return body;
    }

    public void setBody(String body){
        this.body = body;
    }

    public void setUserId(int userId){
        this.userId = userId;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }
    */



}
