package com.example.haneum;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import java.io.IOException;

public class FirstFragment extends Fragment implements View.OnClickListener{

    Button btnstart, btnstop;
    Button temp;
    MediaRecorder mediaRecorder;
    String filepath;
    public static FirstFragment singleton;

    public static FirstFragment newInstance(){
        if (singleton == null){
            singleton = new FirstFragment();
        }
        return singleton;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.activity_firstfrag, container, false);

        btnstart = view.findViewById(R.id.button);
        btnstop = view.findViewById(R.id.button2);
        temp = view.findViewById(R.id.button3);

        btnstart.setOnClickListener(this);
        btnstop.setOnClickListener(this);
        temp.setOnClickListener(this);

        filepath = getActivity().getCacheDir().getAbsolutePath();
        filepath += "/audiorecordtest.mp3";
        Log.d("filepath",filepath);
        return view;
    }


    @Override
    public void onClick(View v){
        if(v == btnstart){
            Log.d("성공", "hi2");
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            mediaRecorder.setOutputFile(filepath);
            try {
                mediaRecorder.prepare();
                mediaRecorder.start();
            }catch (IOException e){
                e.printStackTrace();
            }

        }
        else if(v == btnstop){
            Log.d("성공", "hi3");
            if(mediaRecorder == null){
                return;
            }
            else {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder=null;
            }
        }
        else if(v == temp){
            Intent NewActivity = new Intent(getActivity().getApplicationContext(), StepOneActivity.class);
            startActivity(NewActivity);
        }
    }
}
